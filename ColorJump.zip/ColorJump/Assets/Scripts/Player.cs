﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public string thisColor;
    public GameObject player;
    Rigidbody2D rb;
    public bool GameOver;
    public SpriteRenderer sr;
    public Color yellow;
    public Color blue;
    public Color red;
    public Color pink;
    public int score = 0;
    public int highscore;
    public Text LiveScore;
    public Text HighScore;
    public float gRaviTy;
    public float camLoc;
    public Color startColor;
    public GameObject GameOverPanel;

    // Use this for initialization
    void Start()
    {
        score = 0;
        PlayerPrefs.SetInt("score", score);
        rb = player.GetComponent<Rigidbody2D>();
        thisColor = SetRandomColor();

    }
    public void IncrementScore()
    {
        score += 1;
        LiveScore.text = score.ToString();
    }
    public void StopScore()
    {
        if (PlayerPrefs.HasKey("HighScore"))
        {
            if (score > PlayerPrefs.GetInt("HighScore"))
                PlayerPrefs.SetInt("HighScore", score);
        }
        else
        {
            PlayerPrefs.SetInt("HighScore", score);
        }
        HighScore.text = highscore.ToString();
        Debug.Log(highscore + " hmmmm ");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!GameOver)
        {
            if (Input.GetButtonDown("Jump") || Input.GetMouseButtonDown(0))
            {
                rb.gravityScale = gRaviTy;
                FindObjectOfType<AudioMan>().Play("Clicker");
            }
            

        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        switch (col.tag)
        {
            case "RedC":
                thisColor = "red";
                FindObjectOfType<AudioMan>().Play("ColorChange");

                sr.color = red;
                return;
                break;
            case "YellowC":
                thisColor = "yellow";
                sr.color = yellow;
                FindObjectOfType<AudioMan>().Play("ColorChange");
                return;
                break;
            case "BlueC":
                thisColor = "blue";
                FindObjectOfType<AudioMan>().Play("ColorChange");
                sr.color = blue;
                return;
                break;
            case "PinkC":
                thisColor = "pink";
                FindObjectOfType<AudioMan>().Play("ColorChange");
                sr.color = pink;
                return;
                break;
            default:
                Debug.Log("TakkarPeTakkar ");
                break;

        }
        //RightColor
        if (col.tag == this.thisColor)
        {

            Debug.Log("coltag " + col.tag + " thiscolor " + thisColor);
            FindObjectOfType<AudioMan>().Play("RightColor");
            // camLoc += 4;
            DestroyVillian();
            StopPlayer();
            IncrementScore();


        }
        else if (col.tag != this.thisColor)
        {
            //Wrong Color
            Debug.Log("GameOver");
            //StopScore();
            FindObjectOfType<AudioMan>().Play("Death");
            Destroy(player);
            GameOverPanel.SetActive(true);

            SceneManager.LoadScene(0);
            // Camera.GetComponent<Animator>().Play("CameraShake");

        }
        //Color Switch



    }
    string SetRandomColor()
    {
        int index = Random.Range(0, 3);
        switch (index)
        {
            case 0:
                //      thisColor = "yellow";
                sr.color = yellow;

                return "yellow";
                break;
            case 1:
                //thisColor = "pink";
                sr.color = pink; Debug.Log("thisColor== " + thisColor);
                return "pink";
                break;
            case 2:
                //thisColor = "blue";
                sr.color = blue;
                return "blue";
                break;
            case 3:
                //thisColor = "red";
                sr.color = red;
                return "red";
                break;
            default:
                return "red";
        }
    }
    public void DestroyVillian()
    {
        Debug.Log("Destroyed");
        Destroy(GameObject.FindWithTag("villian"));
    }


    public void StopPlayer()
    {
        rb.gravityScale = 0;
        rb.velocity = new Vector2(0, 0);


    }

    public void RestartGame()
    {

        SceneManager.LoadScene(0);
    }
}
