﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Occillate : MonoBehaviour {


    private float thrust=3f;
    public Rigidbody2D rb;
    public float t = 0.0f;
    public int counter = 1;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
       

        rb.velocity = new Vector2(thrust * counter, 0);
        t = t + Time.deltaTime;
        float dist = thrust * t;
        if (dist>7f)
        {
            counter = counter * -1;
            rb.velocity = new Vector2(2.2f * counter, 0);
            t = 0.0f;
        }
    }
    
}
