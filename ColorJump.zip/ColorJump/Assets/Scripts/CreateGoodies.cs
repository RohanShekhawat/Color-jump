﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateGoodies : MonoBehaviour
{

    public GameObject BlueCandy;
    public GameObject YellowCandy;
    public GameObject RedCandy;
    public GameObject PinkCandy;
    private float NextPos = -1.75f;

    private void Start()
    {
        // Invoke("RepeatVillian",0f);
        CreateCandy(25);
    }

    public void CreateCandy(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int rand = Random.Range(-1, 6);
            Vector3 pos = new Vector3(-2.75f, NextPos, 0);
            GameObject f1;
            switch (rand)
            {
                case 0:
                    f1 = Instantiate(BlueCandy, pos, Quaternion.identity) as GameObject;
                    break;
                case 1:
                    f1 = Instantiate(YellowCandy, pos, Quaternion.identity) as GameObject;
                    break;
                case 2:
                    f1 = Instantiate(RedCandy, pos, Quaternion.identity) as GameObject;
                    break;
                case 3:
                    f1 = Instantiate(PinkCandy, pos, Quaternion.identity) as GameObject;
                    break;
                case 4:
                    Debug.Log("");
                    break;
                case 5:
                    Debug.Log("");
                    break;
                default:
                    Debug.Log("");
                    break;
            }
            NextPos -= 5f;
        }
    }
}
